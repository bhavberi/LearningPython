import random
import login

def private():
    s=''
    letters='qwertyuioplkjhgfdsazxcvbnm'
    letters+=letters.upper()
    letters+='1234567890'
    letters+="!@#$%^&*?/'"
    for i in range(8):
        s+=random.choice(letters)
    return 'AB '+s
passcode,correct = 0,private()

def main(quiz_no=1,passpercent=65):
    if login.login():
        global passcode,correct
        passcode=correct
        file='quiz '+str(quiz_no)+'.txt'
        quiz(file,passpercent)
def quiz(file,passpercent):
    global
    if passcode!=correct:
        print("Fake")
        return
    marks=0
    ob=open(file,'r')
    ans=eval(ob.readline())
    total_ques=len(ans.keys())
    q=ob.readlines()
    done=[]
    no=0
    max_no=int(total_ques/2)
    while True:
        i=random.randint(1,total_ques)
        k=0
        for a in done:
            if i==a:
                k=1
        if k==1:
            continue
        no+=1
        if no>max_no:
            break
        if no<=max_no:
            line=(i-1)*5
            print('\n',no,'.',q[line][2:],end='',sep='')
            for a in range(line+1,line+5):
                print(q[a],end='')
            user_ans=input("Enter your answer no. <1-4>")
            if user_ans==str(ans[i]):
                print('Correct')
                marks+=1
                print("Marks :",marks)
            else:
                print('Wrong')
                print("Marks :",marks)
            done+=[i,]
    print("\nTotal marks obtained are : ",marks,"/",max_no)
    if marks >=((passpercent/100)*max_no):
        print('pass')
    else:
        print('fail')
#main()
